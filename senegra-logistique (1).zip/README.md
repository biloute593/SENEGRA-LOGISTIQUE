
# SENEGRA LOGISTIQUE

This is a showcase website for SENEGRA LOGISTIQUE, detailing their expertise in BTP, civil engineering, equipment rental, sales, and transport. The site is built with React and Tailwind CSS, served as a static application.

## Deployment on Vercel

This project is ready for a seamless deployment on Vercel.

1.  **Connect your Git repository (containing these files) to a new Vercel project.**
2.  **Vercel will automatically detect this as a static site.** No framework preset or build command configuration is necessary. The included `vercel.json` file ensures the correct platform version is used.
3.  **Click "Deploy".** Your site will be live in minutes.
